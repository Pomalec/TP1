﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProblemaAgenteViajero
{
    public class Grafo
    {
        public int Numero_grafo { get; set; }
        public int PosicionX;//coordenada X
       public void setposx(int x) { PosicionX = x; }
       public void setposy(int x) { PosicionY = x; }
        public int PosicionY;//coordenada y

        //public int Arista { get; set; }

        public void Dibujar_grafo(Graphics graphics, Brush solid, Size size, Grafo grafo)
        {
            if (this.PosicionX < size.Width && this.PosicionY < size.Height)
            {
                Random Numeros_aleatorios = new Random();
                graphics.FillEllipse(solid, grafo.PosicionX, grafo.PosicionY, 40, 40);
                graphics.Dispose();

                //this.PosicionX = Numeros_aleatorios.Next(0, size.Width);
                //this.PosicionY = Numeros_aleatorios.Next(0, size.Height);  

            }

        }
    }
    public class ListaGrafos
    {
        public List<Grafo> List_grafos { get; set; }
        public ListaGrafos()
        {
            if (List_grafos == null)
            {
                List_grafos = new List<Grafo>();
            }
        }
        public List<Grafo> Obtener_grafos()
        {
            return List_grafos;
        }
        public void Insertar_grafos(Grafo grafo)
        {
            List_grafos.Add(grafo);
        }
        public void Calcular_distancia()
        {
            // int distancia = 0;
            //Adiciona la arista de 2 nodos
        }
        public void Conectar_nodos(Graphics graphics)
        {
                System.Drawing.Pen pen = new System.Drawing.Pen(System.Drawing.Color.Black,5);
            foreach (Grafo grafo in List_grafos)
            {

            }
            for (int i = 1; i < List_grafos.Count; i++)
            {
                int x1, x2, y1, y2;
                x1 = List_grafos.ElementAt(i - 1).PosicionX;
                y1 = List_grafos.ElementAt(i - 1).PosicionY;
                y2 = List_grafos.ElementAt(i).PosicionY;
                x2 = List_grafos.ElementAt(i).PosicionX;

                graphics.DrawLine(pen,x1,y1,x2, y2);
          
             
            }
        }
    }
    //public class line
    //{
    //    public int cont = 0;
    //    public int posX1;
    //    public int posY1;
    //    public int posX2;
    //    public int posY2;
    //    public void addpoint() { cont++; }
    //    public int getpoint() { return cont; }
    //    public void setPosX1(int x) { posX1 = x; }
    //    public void setPosY1(int y) { posY1 = y; }
    //    public void setPosX2(int x) { posX2 = x; }
    //    public void setPosY2(int y) { posY2 = y; }
    //    public int setline
    //    System.Drawing.Pen pen = new System.Drawing.Pen(System.Drawing.Color.Black);
    //    public void dibujardis(Graphics graphics)
    //    {

    //    }
    //}
    public class Point2
    {
        public int posX;
        public int posY;
        public int value;

        public int getPosX() { return posX; }
        public int getPosY() { return posY; }
        public int getValue() { return value; }
        public void setPosX(int x) { posX = x; }
        public void setPosY(int y) { posY = y; }



        public void dibujar(Graphics graphics)
        {
            System.Drawing.SolidBrush brush = new System.Drawing.SolidBrush(System.Drawing.Color.DarkBlue);
            
            //Pen myPen = new Pen(System.Drawing.Color.DarkGreen, 5);
            Rectangle myRectangle = new Rectangle(posX, posY, 80, 80);
            graphics.FillEllipse(brush,myRectangle);
            //graphics.DrawEllipse(solid, myRectangle);

        }


    
    
    
    }

}
